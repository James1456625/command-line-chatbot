"""LLM 模块单元测试 - 离线跑通，mock 掉 OpenAI client"""

import pytest

import config as config_module
import llm as llm_module
from llm import call_llm


@pytest.fixture(autouse=True)
def _clear_settings_cache():
    """每个测试前清除 lru_cache"""
    config_module.get_settings.cache_clear()
    yield
    config_module.get_settings.cache_clear()


class MockDelta:
    def __init__(self, content: str):
        self.content = content


class MockChoice:
    def __init__(self, content: str = "", delta_content: str = ""):
        self.message = type("MockMessage", (), {"content": content})()
        self.delta = MockDelta(delta_content)


class MockChunk:
    def __init__(self, delta_content: str):
        self.choices = [MockChoice(delta_content=delta_content)]


class MockResponse:
    """模拟 OpenAI 非流式响应"""
    def __init__(self, content: str):
        self.choices = [MockChoice(content=content)]


class MockStreamResponse:
    """模拟 OpenAI 流式响应"""
    def __init__(self, tokens: list[str]):
        self._tokens = tokens

    def __iter__(self):
        for token in self._tokens:
            yield MockChunk(token)


class MockChatCompletions:
    """模拟 client.chat.completions"""
    def __init__(self):
        self.last_call_kwargs = None

    def create(self, **kwargs):
        self.last_call_kwargs = kwargs
        if kwargs.get("stream"):
            return MockStreamResponse(["你", "好", "！"])
        else:
            return MockResponse("你好！")


class MockChat:
    def __init__(self):
        self.completions = MockChatCompletions()


class MockOpenAI:
    """模拟 OpenAI 客户端"""
    def __init__(self, api_key=None, base_url=None):
        self.api_key = api_key
        self.base_url = base_url
        self.chat = MockChat()


@pytest.fixture
def mock_client(monkeypatch, with_env):
    """Mock create_client 返回固定的 MockOpenAI 实例，便于断言调用参数"""
    mock_instance = MockOpenAI()
    monkeypatch.setattr(llm_module, "create_client", lambda: mock_instance)
    return mock_instance


@pytest.fixture
def with_env(monkeypatch):
    """注入测试用环境变量"""
    monkeypatch.setenv("CHATBOT_API_KEY", "sk-test-key")
    monkeypatch.setenv("CHATBOT_MODEL", "test-model")
    monkeypatch.setenv("CHATBOT_BASE_URL", "https://test.example.com/v1")
    monkeypatch.setenv("CHATBOT_TEMPERATURE", "0.5")


class TestLLMParams:
    """断言传给模型的参数符合配置"""

    def test_model_passed_to_client(self, mock_client):
        call_llm([{"role": "user", "content": "hi"}])
        kwargs = mock_client.chat.completions.last_call_kwargs
        assert kwargs is not None
        assert kwargs["model"] == "test-model"

    def test_temperature_passed_to_client(self, mock_client):
        call_llm([{"role": "user", "content": "hi"}])
        kwargs = mock_client.chat.completions.last_call_kwargs
        assert kwargs is not None
        assert kwargs["temperature"] == 0.5

    def test_messages_structure_correct(self, mock_client):
        messages = [
            {"role": "system", "content": "你是助手"},
            {"role": "user", "content": "你好"},
        ]
        call_llm(messages)
        kwargs = mock_client.chat.completions.last_call_kwargs
        assert kwargs is not None
        assert kwargs["messages"] == messages
        # 验证消息结构中 role 和 content 字段存在
        for msg in kwargs["messages"]:
            assert "role" in msg
            assert "content" in msg
            assert msg["role"] in ("system", "user", "assistant")

    def test_stream_true_when_enabled(self, mock_client):
        call_llm([{"role": "user", "content": "hi"}], stream=True)
        kwargs = mock_client.chat.completions.last_call_kwargs
        assert kwargs is not None
        assert kwargs["stream"] is True

    def test_stream_false_when_disabled(self, mock_client):
        call_llm([{"role": "user", "content": "hi"}], stream=False)
        kwargs = mock_client.chat.completions.last_call_kwargs
        assert kwargs is not None
        assert kwargs["stream"] is False


class TestLLMStreamOutput:
    """测试流式输出行为"""

    def test_stream_returns_iterator(self, mock_client):
        result = call_llm([{"role": "user", "content": "hi"}], stream=True)
        tokens = list(result)
        assert tokens == ["你", "好", "！"]
        assert "".join(tokens) == "你好！"

    def test_non_stream_returns_string(self, mock_client):
        result = call_llm([{"role": "user", "content": "hi"}], stream=False)
        assert result == "你好！"
