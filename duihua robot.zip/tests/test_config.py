"""配置模块单元测试 - 离线跑通，不需要真实 API Key"""

import pytest
from pydantic import ValidationError

import config as config_module


@pytest.fixture(autouse=True)
def _clear_settings_cache():
    """每个测试前清除 lru_cache，避免模块级单例污染"""
    config_module.get_settings.cache_clear()
    yield
    config_module.get_settings.cache_clear()


class TestConfigDefaults:
    """测试默认值正确"""

    def test_default_base_url(self, monkeypatch):
        monkeypatch.setenv("CHATBOT_API_KEY", "sk-test-key")
        settings = config_module.get_settings()
        assert settings.CHATBOT_BASE_URL == "https://api.deepseek.com/v1"

    def test_default_model(self, monkeypatch):
        monkeypatch.setenv("CHATBOT_API_KEY", "sk-test-key")
        settings = config_module.get_settings()
        assert settings.CHATBOT_MODEL == "deepseek-chat"

    def test_default_temperature(self, monkeypatch):
        monkeypatch.setenv("CHATBOT_API_KEY", "sk-test-key")
        settings = config_module.get_settings()
        assert settings.CHATBOT_TEMPERATURE == 0.7

    def test_default_max_tokens(self, monkeypatch):
        monkeypatch.setenv("CHATBOT_API_KEY", "sk-test-key")
        settings = config_module.get_settings()
        assert settings.CHATBOT_MAX_TOKENS == 2048

    def test_default_max_history(self, monkeypatch):
        monkeypatch.setenv("CHATBOT_API_KEY", "sk-test-key")
        settings = config_module.get_settings()
        assert settings.CHATBOT_MAX_HISTORY == 20


class TestConfigValidation:
    """测试配置校验"""

    def test_temperature_too_high_raises_validation_error(self, monkeypatch):
        """CHATBOT_TEMPERATURE=5 超出范围应抛 ValidationError"""
        monkeypatch.setenv("CHATBOT_API_KEY", "sk-test-key")
        monkeypatch.setenv("CHATBOT_TEMPERATURE", "5")
        with pytest.raises(ValidationError):
            config_module.get_settings()

    def test_temperature_below_zero_raises_validation_error(self, monkeypatch):
        """CHATBOT_TEMPERATURE=-0.1 超出范围应抛 ValidationError"""
        monkeypatch.setenv("CHATBOT_API_KEY", "sk-test-key")
        monkeypatch.setenv("CHATBOT_TEMPERATURE", "-0.1")
        with pytest.raises(ValidationError):
            config_module.get_settings()


class TestSecretStr:
    """测试 SecretStr 不明文输出"""

    def test_api_key_is_secretstr(self, monkeypatch):
        monkeypatch.setenv("CHATBOT_API_KEY", "sk-my-secret-key-123")
        settings = config_module.get_settings()
        assert settings.CHATBOT_API_KEY.get_secret_value() == "sk-my-secret-key-123"

    def test_print_settings_does_not_expose_secret(self, monkeypatch, capsys):
        """print(settings) 时不能出现明文 API Key"""
        monkeypatch.setenv("CHATBOT_API_KEY", "sk-my-secret-key-123")
        settings = config_module.get_settings()
        print(settings)
        captured = capsys.readouterr().out
        assert "sk-my-secret-key-123" not in captured

    def test_str_repr_hides_secret(self, monkeypatch):
        """str() 转换也不应暴露密钥"""
        monkeypatch.setenv("CHATBOT_API_KEY", "sk-my-secret-key-123")
        settings = config_module.get_settings()
        s = str(settings)
        assert "sk-my-secret-key-123" not in s
